package com.example.chapter2test;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.*;


import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    static class ViewHolder extends RecyclerView.ViewHolder {
        View ItemView;
        TextView ItemNo;
        TextView ItemTitle;
        TextView ItemHeat;

        public ViewHolder(View viewx)
        {
            super(viewx);
            ItemView = viewx;
            ItemNo = viewx.findViewById(R.id.ItemNo);
            ItemTitle = viewx.findViewById(R.id.ItemTitle);
            ItemHeat = viewx.findViewById(R.id.ItemHeat);
        }
    }

    private List<Item> mItemList;

    public MyAdapter(List<Item> itemList)
    {
        mItemList = itemList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_list,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Item item = mItemList.get(position);
        holder.ItemNo.setText(item.getNo());
        holder.ItemTitle.setText(item.getTitle());
        holder.ItemHeat.setText(item.getHeat());
    }

    @Override
    public int getItemCount()
    {
        return mItemList.size();
    }

}