package com.example.chapter2test;

import java.util.Comparator;

public class Cmp implements Comparator<Item> { //The class to compare two Items.

    @Override
    public int compare(Item s1, Item s2)
    {
        return Integer.valueOf(s2.getHeat()) - Integer.valueOf(s1.getHeat());
    }


}
