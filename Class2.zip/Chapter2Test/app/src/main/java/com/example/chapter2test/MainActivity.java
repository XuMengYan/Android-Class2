package com.example.chapter2test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.*;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private List<Item> mItemList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        RecyclerView rv = findViewById(R.id.rv_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        rv.setLayoutManager(layoutManager);

        Collections.sort(mItemList, new Cmp()); //sort by heat
        for(int i = 1; i <= mItemList.size(); ++i) mItemList.get(i-1).setNo(i); //set items' No
        MyAdapter adapter = new MyAdapter(mItemList);
        rv.setAdapter(adapter);

        final EditText editTitle = findViewById(R.id.edit_newTitle);
        final EditText editHeat = findViewById(R.id.edit_newHeat);
        Button btnAdd = findViewById(R.id.btn_add);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newTitle, newHeat;
                newTitle = editTitle.getText().toString();
                newHeat = editHeat.getText().toString();
                if(newTitle.length() == 0 || newHeat.length() == 0) return;
                mItemList.add(new Item("", newTitle, newHeat));
                Collections.sort(mItemList, new Cmp());
                for(int i = 1; i <= mItemList.size(); ++i) mItemList.get(i-1).setNo(i);
                RecyclerView rv = findViewById(R.id.rv_list);
                rv.setAdapter(new MyAdapter(mItemList));
            }
        });

    }


    private void init()
    {
        mItemList.add(new Item("", "AAAAA", "99999"));
        mItemList.add(new Item("", "BBBBB", "9999"));
        mItemList.add(new Item("", "CCCCC", "8888"));
        mItemList.add(new Item("", "DDDDD", "7777"));
        mItemList.add(new Item("", "EEEEE", "22222"));
        mItemList.add(new Item("", "FFFFF", "66666"));
        mItemList.add(new Item("", "GGGGG", "555555"));
        mItemList.add(new Item("", "HHHHH", "44444"));
        mItemList.add(new Item("", "IIIII", "888888"));
        mItemList.add(new Item("", "JJJJJ", "11111"));
        mItemList.add(new Item("", "KKKKK", "77777"));
        mItemList.add(new Item("", "LLLLL", "33333"));
    }



}
