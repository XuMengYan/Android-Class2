package com.example.chapter2test;


public class Item{ //Item class.
    private String no, title, heat;

    public Item(String nox, String titlex, String heatx)
    {
        this.no = nox;
        this.title = titlex;
        this.heat = heatx;
    }

    public String getNo()
    {
        return no;
    }
    public void setNo(int no)
    {
        this.no = Integer.toString(no) + ".";
    }

    public String getTitle()
    {
        return title;
    }
    public String getHeat()
    {
        return heat;
    }
}